import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
//import jwt_decode from 'jwt-decode';
import { jwtDecode } from 'jwt-decode';

import '../styles/HomePage.css';

const HomePage = () => {
  const [userId, setUserId] = useState('');
  const navigate = useNavigate();

  // useEffect(() => {
  //   // Fetch the user ID and user name from session storage
  //   setUserId(sessionStorage.getItem('UserId'));
  // }, []);

  // const handleProfileClick = () => {
  //   if (userId) {
  //     navigate(`/profile/${userId}`);
  //   } else {
  //     navigate('/login');
  //   }
  // };

  useEffect(() => {
    const token = localStorage.getItem('token'); // Retrieve JWT token from localStorage
    if (token) {
      // Decode JWT token to extract user ID
      const decoded = jwtDecode(token);
      setUserId(decoded.userId);
    }
  }, []);

  const handleProfileClick = () => {
    if (userId) {
      navigate(`/profile/${userId}`);
    } else {
      navigate('/login');
    }
  };

  return (
    <div className="home-page">
      <div className="header">
        <div className="options-bar">
          <Link to="/contests" className="option">Contest</Link>
          <Link to="/gyms" className="option">Gym</Link>
          <Link to="/blogs" className="option">Blogs</Link>
          <Link to="/rankings" className="option">Rankings</Link>
        </div>
        {/* Render the link to the profile page with the user ID */}
        <button className="profile-option" onClick={handleProfileClick}>
          {userId ? 'Profile' : 'Login'}
        </button>
      </div>
      <div className="content">
        <h2>Welcome to Codeforces!</h2>
      </div>
    </div>
  );
};

export default HomePage;